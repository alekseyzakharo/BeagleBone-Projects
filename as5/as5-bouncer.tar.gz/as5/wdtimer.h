//Aleksey Zakharov 301295506
//Barebone Assignment: wdtimer.h
//CMPT 433 - Assignment 5

#ifndef WDTIMER_H_
#define WDTIMER_H_

//watch dog init
void Watchdog_init(void);

//pat the dog
void Watchdog_hit(void);

#endif /* WDTIMER_H_ */
