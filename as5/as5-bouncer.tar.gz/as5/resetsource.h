//Aleksey Zakharov 301295506
//Barebone Assignment: resetsource.h
//CMPT 433 - Assignment 5

#ifndef _RESETSOURCE_H_
#define _RESETSOURCE_H_

//function check and resets reset register, and prints how the beaglebone was recently reset
void Resetsource_PrintAndResetRegister(void);

#endif
